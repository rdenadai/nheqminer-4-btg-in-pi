./nheqminer -l equihash.eu.nicehash.com:3357 -u 1GaGRtcCjb7ThaDgDLjgVwV8fctzEf12ct.mac -p x -t 4
